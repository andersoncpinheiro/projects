/// <reference types="cypress" />

describe('Home', () => {

  it('webapp deve estar online', () => {
    cy.visit('http://localhost:8080')
    
    //carregar com a linha abaixo somente em casos de acesso a localhost
    Cypress.on('uncaught:exception', (err, runnable) => { return false; })
    
    cy.title().should('eq', 'Gerencie suas tarefas com Mark L')

    

  })

})