///<reference types= "cypress"/>

describe('tarefas', () => {

  context('cadastro',() =>{

  it('Deve adicionar tarefas', () => {

    const taskName = "Ler um livro node.js"

    cy.removeTaskByName(taskName)
    cy.createTask(taskName)
    cy.contains("main div p", taskName)
      .should("be.visible")
  })
 
  it("Nao deve ter tarefa duplicada", () => {

    const task = {
      name: "Estudar Javascript",
      is_done: false
    }

    cy.removeTaskByName(task.name)
    cy.postTask(task)
    cy.createTask(task.name)

   cy.get(".swal2-html-container")
      .should("be.visible")
      .should("have.text", "Task already exists!")
  })

  it('Campo Obrigatório',()=>{
    cy.emptyTask()

    cy.get('input[placeholder="Add a new Task"')
      .invoke('prop', 'validationMessage')
      .should((text) =>{
          expect(
            'This is a required field'
          ).to.eq(text)
      })
  })
  })

  context('atualização',() =>{
    it('deve concluir a tarefa',()=>{
      const task = {
        name: 'Pagar contas de consumo',
        is_done: false
    }

      cy.removeTaskByName(task.name)
      cy.postTask(task)
     
      cy.visit('http://localhost:8080')

      cy.contains('p', task.name)
          .parent()
          .find('button[class*=ItemToggle]')
          .click() 

      cy.contains('p', task.name)
        .should('have.css', 'text-decoration-line', 'line-through')
    })
  })
  context('exclusão',() =>{
    it('deve remover a tarefa',()=>{
      const task = {
        name: 'Estudar Javascript',
        is_done: false
    }

      cy.removeTaskByName(task.name)
      cy.postTask(task)
     
      cy.visit('http://localhost:8080')

      cy.contains('p', task.name)
          .parent()
          .find('button[class*=ItemDelete]')
          .click() 

      cy.contains('p', task.name)
        .should('not.exist')
    })
  })
})