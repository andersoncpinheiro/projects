/// <reference types="cypress" />

//import { faker } from '@faker-js/faker';

describe('tasks', () => {
    context('Tasks criadas para estudo', () =>{
        it('deve cadastrar uma nova tarefa', () => {

              cy.request({
                url:'http://localhost:3333/helper/tasks',
                method: "DELETE",
                body:{name: 'ler um livro de Node.js'}
              }).then(response =>{
                expect(response.status).to.eq(204)
              })    

              cy.visit('http://localhost:8080')
              //carregar com a linha abaixo somente em casos de acesso a localhost
              Cypress.on('uncaught:exception', (err, runnable) => { return false; })
              cy.get('input[placeholder="Add a new Task"]').type('ler um livro de Node.js')
              //.type(faker.name.firstName() + " " +faker.name.lastName())
              cy.contains('button','Create').click()  
              cy.contains('main div p', 'ler um livro de Node.js')
              .should('be.visible')
        })

        it('Não deve permitir tarefa duplicada', () => {
        
          cy.request({
            url:'http://localhost:3333/helper/tasks',
            method: "DELETE",
            body:{name: 'Estudar Rails'}
          }).then(response =>{
            expect(response.status).to.eq(204)
          })    

        //Registra dado
          cy.request({
            url:'http://localhost:3333/tasks',
            method: "POST",
            body:{name: 'Estudar Rails', is_done: false}
          }).then(response =>{
            expect(response.status).to.eq(201)


          })

          //Realiza nova tentativa de cadastro
          cy.visit('http://localhost:8080')
          Cypress.on('uncaught:exception', (err, runnable) => { return false; })
          cy.get('input[placeholder="Add a new Task"]').type('Estudar Rails')
          //.type(faker.name.firstName() + " " +faker.name.lastName())
          cy.contains('button','Create').click()  
          cy.get('.swal2-html-container').should('be.visible').should('have.text', 'Task already exists!')
        })


    })
})