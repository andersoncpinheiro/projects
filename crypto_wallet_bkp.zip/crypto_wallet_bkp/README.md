# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...

Para uso da aplicação em outros micros, ex micro fora
usar os comandos

listar versões ruby
asdf list

* estando na pasta do projeto inserir
asdf local ruby colocar a versão

instalar versão especifica
asdf install ruby 3.2.0

andersoncpinheiro
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
