module CoinsHelper
end
