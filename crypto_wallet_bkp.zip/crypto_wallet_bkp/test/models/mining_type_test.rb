require "test_helper"

class MiningTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
