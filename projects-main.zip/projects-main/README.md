# projects
Projetos com base em estudos em cursos de desenvolvimento focado
em JS, ainda estou organizando os repositórios e aprendendo enquanto
realizo o upload deste arquivos, então qualquer coisa que esteja fora do lugar, 
peço desculpas de antemão. 

Qualquer dúvida ou sugestão estou a disposição.
