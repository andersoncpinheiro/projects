Criando projeto em react

Mkdir para criar nova pasta para instalar o projeto.

Comando para criar o projeto React
npm create vite@latest reactapp --template react

Instalar o node_moduls
npm install

Iniciar o projeto react
npm run dev
